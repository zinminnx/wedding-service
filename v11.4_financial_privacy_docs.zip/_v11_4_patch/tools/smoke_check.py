from pathlib import Path
import os
import sys

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

import django
django.setup()

from django.urls import resolve, reverse
from budgeting.models import BudgetItem
from financial_docs.models import FinancialAuditEvent, FinancialDocument

assert hasattr(BudgetItem, "visibility")
assert BudgetItem.Visibility.PRIVATE == "PRIVATE"
assert BudgetItem.Visibility.SHARED == "SHARED"
assert FinancialDocument.DocumentType.RECEIPT == "RECEIPT"
assert FinancialAuditEvent._meta.get_field("wedding")
assert resolve("/dashboard/finance-docs/").url_name == "dashboard"
assert reverse("financial_docs:dashboard") == "/dashboard/finance-docs/"
print("Financial privacy, secure documents and audit models: OK")
