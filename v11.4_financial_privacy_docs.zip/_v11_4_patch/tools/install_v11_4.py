from pathlib import Path
import datetime
import re
import shutil
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
PATCH_ROOT = Path(__file__).resolve().parents[1]
PAYLOAD = PATCH_ROOT / "payload"
BACKUP_ROOT = ROOT.parent / "_everafter_patch_backups" / ("v11_4_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))


def require(rel):
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f"Required file not found: {rel}. Install prerequisite patches first.")
    return path


def read(rel):
    return require(rel).read_text(encoding="utf-8-sig")


def backup(path):
    if not path.exists():
        return
    rel = path.relative_to(ROOT)
    dest = BACKUP_ROOT / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if path.is_dir():
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(path, dest)
    else:
        shutil.copy2(path, dest)


def write(rel, text):
    path = ROOT / rel
    backup(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def copy_file(src_rel, dst_rel=None):
    dst_rel = dst_rel or src_rel
    src = PAYLOAD / src_rel
    if not src.exists():
        raise SystemExit(f"Patch payload missing: {src_rel}")
    dst = ROOT / dst_rel
    if dst.exists():
        backup(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print(f"Installed: {dst_rel}")


def copy_tree(src_rel, dst_rel=None):
    dst_rel = dst_rel or src_rel
    src = PAYLOAD / src_rel
    dst = ROOT / dst_rel
    if not src.exists():
        raise SystemExit(f"Patch payload missing: {src_rel}")
    for item in src.rglob("*"):
        if item.is_dir():
            continue
        rel = item.relative_to(src)
        target = dst / rel
        if target.exists():
            backup(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)
        print(f"Installed: {Path(dst_rel) / rel}")


require("manage.py")
require("budgeting/models.py")
require("budgeting/migrations/0001_initial.py")
require("vendors/models.py")
require("vendors/migrations/0001_initial.py")
require("planner/apps.py")
require("staffing/access.py")
require("modules/middleware.py")
require("weddings/templates/dashboard/base.html")
require("config/settings.py")
require("config/urls.py")

# Replace only the budgeting files owned by this milestone. Keep the old CSS intact
# and layer privacy.css separately so existing UI styling cannot regress.
for rel in [
    "budgeting/models.py",
    "budgeting/forms.py",
    "budgeting/services.py",
    "budgeting/views.py",
    "budgeting/admin.py",
    "budgeting/migrations/0002_financial_privacy.py",
    "budgeting/templates/budgeting/dashboard.html",
    "budgeting/templates/budgeting/item_form.html",
    "budgeting/static/budgeting/css/privacy.css",
    "vendors/services.py",
]:
    copy_file(rel)

copy_tree("financial_docs")

# Register app.
rel = "config/settings.py"
text = read(rel)
if re.search(r'^\s*["\']financial_docs["\'],?\s*$', text, re.M) is None:
    anchors = ['    "vendors",', '    "budgeting",', '    "planner",']
    marker = next((item for item in anchors if item in text), None)
    if marker is None:
        raise SystemExit("Could not find safe INSTALLED_APPS anchor for financial_docs")
    text = text.replace(marker, marker + '\n    "financial_docs",', 1)
    write(rel, text)
    print("Updated: config/settings.py")
else:
    print("No change needed: financial_docs already in INSTALLED_APPS")

# Register URLs.
rel = "config/urls.py"
text = read(rel)
if 'include("financial_docs.urls")' not in text and "include('financial_docs.urls')" not in text:
    marker = "urlpatterns = ["
    if marker not in text:
        raise SystemExit("Could not find urlpatterns in config/urls.py")
    text = text.replace(marker, marker + '\n    path("", include("financial_docs.urls")),', 1)
    write(rel, text)
    print("Updated: config/urls.py")
else:
    print("No change needed: financial_docs URLs already included")

# Route Financial Docs through the existing Budgeting module gate. No extra optional
# module is introduced just for attachments.
rel = "modules/middleware.py"
text = read(rel)
if '"financial_docs": "budgeting"' not in text:
    candidates = ['    "budgeting": "budgeting",', '    "vendors": "vendors",', '    "planner": "planner",']
    marker = next((item for item in candidates if item in text), None)
    if marker is None:
        raise SystemExit("Could not find module middleware insertion point")
    text = text.replace(marker, marker + '\n    "financial_docs": "budgeting",', 1)
    write(rel, text)
    print("Updated: financial_docs uses Budgeting module gate")
else:
    print("No change needed: financial_docs middleware gate already present")

# Keep the existing Owner/Manager Budget navigation untouched. Add a separate
# Budget link only for Planner-only users so we do not disturb prior nested template
# conditions from v11.1/v11.2 patches.
rel = "weddings/templates/dashboard/base.html"
text = read(rel)
if "v11.4 planner finance navigation" not in text:
    nav = '''            {# v11.4 planner finance navigation #}
            {% if access.planner and not access.manage_wedding %}{% if 'budgeting' in enabled_modules %}
            <a class="nav-item {% if request.resolver_match.namespace == 'budgeting' %}active{% endif %}" href="{% url 'budgeting:dashboard' %}">Budget</a>
            {% endif %}{% endif %}
            {% if access.manage_wedding or access.planner %}{% if 'budgeting' in enabled_modules %}
            <a class="nav-item {% if request.resolver_match.namespace == 'financial_docs' %}active{% endif %}" href="{% url 'financial_docs:dashboard' %}">Financial Docs</a>
            {% endif %}{% endif %}
'''
    marker = '<div class="sidebar-quote">'
    if marker not in text:
        raise SystemExit("Could not find safe Financial Docs navigation anchor")
    text = text.replace(marker, nav + marker, 1)
    write(rel, text)
    print("Updated: Planner Budget + Financial Docs navigation")
else:
    print("No change needed: v11.4 finance navigation already present")

print(f"Backup created outside project: {BACKUP_ROOT}")
