$ErrorActionPreference = "Stop"

Write-Host "EverAfter v11.4 - Financial Privacy & Documents" -ForegroundColor Cyan

$Root = (Resolve-Path $PSScriptRoot).Path
if (-not (Test-Path (Join-Path $Root "manage.py"))) {
    throw "Extract this ZIP into the wedding-service project root (the folder containing manage.py)."
}

$Python = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { $Python = "python" }
$PatchDir = Join-Path $Root "_v11_4_patch"
$Installer = Join-Path $PatchDir "tools\install_v11_4.py"
$SmokeScript = Join-Path $PatchDir "tools\smoke_check.py"

if (-not (Test-Path $Installer)) {
    throw "_v11_4_patch payload is missing. Extract the complete ZIP before running apply_patch.ps1."
}

& $Python $Installer $Root
if ($LASTEXITCODE -ne 0) { throw "v11.4 file installation failed. Stop and report this output." }

Write-Host "Applying database migrations..." -ForegroundColor Yellow
& $Python (Join-Path $Root "manage.py") migrate
if ($LASTEXITCODE -ne 0) { throw "Migration failed. Stop and report this output." }

Write-Host "Refreshing Module Registry..." -ForegroundColor Yellow
& $Python (Join-Path $Root "manage.py") seed_modules
if ($LASTEXITCODE -ne 0) { throw "Module Registry refresh failed. Stop and report this output." }

Write-Host "Checking Django project..." -ForegroundColor Yellow
& $Python (Join-Path $Root "manage.py") check
if ($LASTEXITCODE -ne 0) { throw "Django system check failed. Stop and report this output." }

Write-Host "Checking for missing migrations..." -ForegroundColor Yellow
& $Python (Join-Path $Root "manage.py") makemigrations --check --dry-run
if ($LASTEXITCODE -ne 0) { throw "Model changes exist without migrations. Stop and report this output." }

Write-Host "Running Financial Privacy smoke check..." -ForegroundColor Yellow
& $Python $SmokeScript $Root
if ($LASTEXITCODE -ne 0) { throw "Financial Privacy smoke check failed. Stop and report this output." }

if (Test-Path $PatchDir) {
    Remove-Item $PatchDir -Recurse -Force
}

Write-Host ""
Write-Host "EverAfter v11.4 Financial Privacy & Documents installed successfully." -ForegroundColor Green
Write-Host "Budget:    http://127.0.0.1:8000/dashboard/budget/" -ForegroundColor Green
Write-Host "Documents: http://127.0.0.1:8000/dashboard/finance-docs/" -ForegroundColor Green
Write-Host "Next roadmap: v12.0 OneDrive Storage / Microsoft Graph foundation." -ForegroundColor Green
